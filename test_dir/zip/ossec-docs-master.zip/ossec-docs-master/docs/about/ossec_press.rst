.. _ossec_press:



Press
=====


OSSEC is #27 on the SecTools.Org: Top 125 Network Security Tools
----------------------------------------------------------------

As of November 18 2011 OSSEC is ranked 27th on SecTools.Org's Top 125 list.

  *"OSSEC HIDS performs log analysis, integrity checking, rootkit detection, time-based alerting and active response. In addition to its IDS functionality, it is commonly used as a SEM/SIM solution. Because of its powerful log analysis engine, ISPs, universities and data centers are running OSSEC HIDS to monitor and analyze their firewalls, IDSs, web servers and authentication logs."*

  `OSSEC on sectools.org <http://sectools.org/tool/ossec/>`_






