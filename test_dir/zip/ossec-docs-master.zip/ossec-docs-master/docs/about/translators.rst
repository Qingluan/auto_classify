Languages and respective translators for the installation
---------------------------------------------------------


* Spanish
  * Meir Michanie - meirm ( at ) riunx.com

* Serbian
  * Maja Michanie - majam ( at ) riunx.com
    
* Russian
  * Yuri Slobodyanyuk - yurisk ( at ) inbox.ru

* French
  * Yves Bigliazzi - yves.bigliazzi ( at ) gmail.com

* Japanese
  * Kuzuno Hiroki - kuzuno ( at )gmail.com

* German
  * Peter Ahlert - peter @ ( at ) ifup.de
    
* Turkish
  * Ahmet Ozturk - oahmet @ ( at ) metu-dot-edu-dot-tr
    
* Polish
  * Dziankowski Krzysztof - oink @ ( at ) onet.eu

* Italian
  * Alberto Furia - straluna ( at ) email.it

* Portuguese
  * Willian Itiho Amano - itihoitiho ( at ) gmail.com
  * Allan Soares - allan.soares ( at ) gmail.com
  * Daniel Barcellos - danielpoa.rs ( at ) gmail.com
  * Liliane Cid - liliane.alves ( at ) gmail.com

* Chinese
  * Jambo Zhang - jamboman ( at ) 163.com

