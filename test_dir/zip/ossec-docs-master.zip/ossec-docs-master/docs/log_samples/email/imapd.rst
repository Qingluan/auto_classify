Log Samples from imapd
----------------------

Failed logins:
^^^^^^^^^^^^^^

.. code-block:: console

  imapd[25015]: Login failed user=grasielle auth=grasielle host=imapd.lab.ossec.net [1.2.3.4]
  imapd[25015]: Login failed user=grasielle auth=grasielle host=imapd.lab.ossec.net [1.2.3.4]

