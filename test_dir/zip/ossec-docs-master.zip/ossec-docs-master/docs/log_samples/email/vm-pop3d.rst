Log Samples for VM-POP3d
------------------------

.. code-block:: console

  May 15 06:54:43 servername vm-pop3d[24029]: Session ended for no user from 70.89.46.205
  May 15 06:54:43 servername vm-pop3d[24110]: User 'jobs' - failed auth, from=70.89.46.205
  May 15 06:54:44 servername vm-pop3d[24109]: Session ended for no user from 70.89.46.205
  May 15 06:54:44 servername vm-pop3d[24070]: Session ended for no user from 70.89.46.205
  May 15 06:54:44 servername vm-pop3d[24118]: Session ended for no user from 70.89.46.205
  May 15 06:54:44 servername vm-pop3d[24119]: Session ended for no user from 70.89.46.205
  May 15 06:54:45 servername vm-pop3d[24120]: User 'jimm' - failed auth, from=70.89.46.205
  May 15 06:54:45 servername vm-pop3d[24072]: Session ended for no user from 70.89.46.205
  May 15 06:54:45 servername vm-pop3d[24121]: User 'jerome' - failed auth, from=70.89.46.205
  May 15 06:54:46 servername vm-pop3d[24090]: Session ended for no user from 70.89.46.205
  May 15 06:54:46 servername vm-pop3d[24139]: Session ended for no user from 70.89.46.205
  May 15 06:54:46 servername vm-pop3d[24091]: Session ended for no user from 70.89.46.205
  May 15 06:54:46 servername vm-pop3d[24140]: User 'john' - failed auth, from=70.89.46.205
  May 15 06:54:46 servername vm-pop3d[24141]: User 'jesse' - failed auth, from=70.89.46.205
  Nov 15 13:26:12 h9-45 vm-pop3d: vm-pop3d startup succeeded
  Nov 15 13:26:16 h9-45 vm-pop3d: vm-pop3d startup succeeded
  Nov 15 13:26:21 h9-45 vm-pop3d: vm-pop3d startup succeeded
  Nov 15 13:26:31 h9-45 vm-pop3d: vm-pop3d shutdown failed


