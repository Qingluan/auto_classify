Log Samples from SonicWall
--------------------------

Log explained: http://www.sonicwall.com/downloads/SonicOS_Log_Event_Reference_Guide.pdf

General logs:
^^^^^^^^^^^^^

.. code-block:: console

  Jan  3 13:45:36 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:06" fw=1.1.1.1 pri=6 c=262144 m=98 msg="Connection Opened" n=23419 src=2.2.2.2:36701:WAN dst=1.1.1.1:50000:WAN proto=tcp/50000
  Jan  3 13:45:36 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:07" fw=1.1.1.1 pri=1 c=32 m=30 msg="Administrator login denied due to bad credentials" n=7 src=2.2.2.2:36701:WAN dst=1.1.1.1:50000:WAN
  Jan  3 13:45:36 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:07" fw=1.1.1.1 pri=6 c=262144 m=98 msg="Connection Opened" n=23420 src=2.2.2.2:36702:WAN dst=1.1.1.1:50000:WAN proto=tcp/50000
  Jan  3 13:45:37 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:07" fw=1.1.1.1 pri=6 c=1024 m=537 msg="Connection Closed" n=567996 src=192.168.4.10:27577:WAN dst=192.168.5.10:53:LAN proto=tcp/dns sent=257 rcvd=242 
  Jan  3 13:45:37 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:08" fw=1.1.1.1 pri=6 c=1024 m=537 msg="Connection Closed" n=567997 src=192.168.5.56:4277:LAN dst=192.168.1.100:1026:WAN proto=tcp/1026 sent=3590 rcvd=13042 vpnpolicy="name"
  Jan  3 13:45:39 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:10" fw=1.1.1.1 pri=6 c=1024 m=537 msg="Connection Closed" n=567999 src=192.168.5.56:4280:LAN dst=192.168.2.81:41850:WAN proto=tcp/41850 sent=386026 rcvd=454118 vpnpolicy="name"
  Jan  3 13:45:39 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:10" fw=1.1.1.1 pri=6 c=1024 m=537 msg="Connection Closed" n=567999 src=1.1.1.1:500:WAN dst=2.2.2.2:500:WAN proto=udp/500 sent=344 rcvd=152 
  Jan  3 13:45:40 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:10" fw=1.1.1.1 pri=6 c=262144 m=98 msg="Connection Opened" n=23421 src=2.2.2.2:36703:WAN dst=1.1.1.1:50000:WAN proto=tcp/50000
  Jan  3 13:45:40 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:10" fw=1.1.1.1 pri=1 c=32 m=30 msg="Administrator login denied due to bad credentials" n=8 src=2.2.2.2:36703:WAN dst=1.1.1.1:50000:WAN
  Jan  3 13:45:40 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:11" fw=1.1.1.1 pri=6 c=262144 m=98 msg="Connection Opened" n=23422 src=2.2.2.2:36704:WAN dst=1.1.1.1:50000:WAN proto=tcp/50000
  Jan  3 13:45:43 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:14" fw=1.1.1.1 pri=5 c=256 m=38 msg="ICMP packet dropped" n=22070 src=219.89.19.223:1026:WAN dst=1.1.1.1:6822:WAN  type=3 code=3 
  Jan  3 13:45:43 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:14" fw=1.1.1.1 pri=6 c=1024 m=537 msg="Connection Closed" n=568000 src=219.89.19.223:1026:WAN dst=1.1.1.1:0:WAN proto=udp/0 
  Jan  3 13:45:44 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:15" fw=1.1.1.1 pri=6 c=16 m=346 msg="IKE Initiator: Start Quick Mode (Phase 2)." n=171872 src=2.2.2.2:500 dst=1.1.1.1:500
  Jan  3 13:45:44 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:15" fw=1.1.1.1 pri=6 c=262144 m=98 msg="Connection Opened" n=23423 src=1.1.1.1:500:WAN dst=2.2.2.2:500:WAN proto=udp/500
  Jan  3 13:45:44 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:15" fw=1.1.1.1 pri=4 c=16 m=483 msg="Received notify: INVALID_ID_INFO" n=171625 src=2.2.2.2:500 dst=1.1.1.1:500
  Jan  3 13:45:45 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:15" fw=1.1.1.1 pri=6 c=262144 m=98 msg="Connection Opened" n=23424 src=192.168.115.10:11549:WAN dst=192.168.5.10:53:LAN proto=tcp/dns
  Jan  3 13:45:46 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:17" fw=1.1.1.1 pri=6 c=262144 m=98 msg="Connection Opened" n=23425 src=192.168.5.64:3182:LAN dst=192.168.1.100:445:WAN proto=tcp/445
  Jan  3 13:45:47 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:18" fw=1.1.1.1 pri=6 c=1024 m=537 msg="Connection Closed" n=568001 src=2.2.2.2:36699:WAN dst=1.1.1.1:50000:WAN proto=tcp/50000 sent=1557 rcvd=957 
  Jan  3 13:45:49 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:20" fw=1.1.1.1 pri=6 c=1024 m=537 msg="Connection Closed" n=568002 src=192.168.5.10:3417:LAN dst=192.168.1.100:53:WAN proto=udp/dns sent=401 rcvd=254 vpnpolicy="name"
  Jan  3 13:45:50 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:20" fw=1.1.1.1 pri=6 c=262144 m=98 msg="Connection Opened" n=23426 src=192.168.125.75:524:WAN dst=192.168.5.10:3582:LAN proto=udp/3582
  Jan  3 13:45:50 192.168.5.1 id=firewall sn=000SERIAL time="2007-01-03 14:48:21" fw=1.1.1.1 pri=6 c=262144 m=98 msg="Connection Opened" n=23427 src=192.168.6.10:28503:WAN dst=192.168.5.10:53:LAN proto=tcp/dns



Dropped events:
^^^^^^^^^^^^^^^

.. code-block:: console

  id=firewall sn=00XX time="2005-10-22 00:12:11" fw=1.2.3.4 pri=5 c=128 m=37 msg="UDP packet dropped" n=14333 src=1.3.4.5 dst=2.5.6.7:1025:LAN
Apr 1 10:45:16 10.1.5.1 id=firewall sn=00301E0526B1 time="2004-04-01 10:39:35" fw=67.32.44.2 pri=5 c=64 m=36 msg="TCP connection dropped" n=2686 src=67.101.200 .27:4507:WAN dst=67.32.44.2:445:LAN proto=tcp



