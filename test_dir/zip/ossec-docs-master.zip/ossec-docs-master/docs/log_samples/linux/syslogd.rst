Log samples for syslogd
-----------------------

Syslogd on OpenBSD (exiting and restarting):
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: console

  Dec 19 20:00:01 enigma syslogd: restart
  Dec 20 01:00:01 enigma syslogd: restart
  Dec 20 14:29:41 enigma syslogd: exiting on signal 15



Syslogd on Ubuntu (exiting and restarting):
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: console

  Dec 19 07:35:21 localhost exiting on signal 15
  Dec 19 16:49:31 localhost syslogd 1.4.1#17ubuntu3: restart.



