Log samples for errors on xfs partitions: 
-----------------------------------------

.. code-block:: console

  Jun  8 13:39:55 www kernel:  <1>XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
  Jun  8 13:39:55 www kernel: XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
  Jun  8 13:39:55 www kernel: XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
  Jun  8 13:39:55 www kernel: XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
  Jun  8 13:39:55 www kernel: XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
  Jun  9 14:04:32 www kernel:  <1>XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50
  Jun  9 14:04:32 www kernel: XFS internal error XFS_WANT_CORRUPTED_RETURN at line 295 of file fs/xfs/xfs_alloc.c.  Caller 0xf892df50



