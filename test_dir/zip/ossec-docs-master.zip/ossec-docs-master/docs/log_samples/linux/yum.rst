Yum log samples
---------------

.. code-block:: console

  Dec  7 07:05:06 ax yum: Installed: libX11-devel - 1.0.3-9.el5.i386
  Dec  7 07:05:06 ax yum: Installed: libXext-devel - 1.0.1-2.1.i386
  Dec  7 07:05:07 ax yum: Installed: libICE-devel - 1.0.1-2.1.i386
  Dec  7 14:03:48 axz yum-updatesd-helper: error getting update info: Cannot retrieve repository metadata (repomd.xml) for repository: rhel-x86_64-server-vt-5. Please verify its path and try again
  Dec 18 01:50:16 xyz yum: Updated: nspr - 4.7.3-2.el5.x86_64
  Dec 18 01:50:16 xyz yum: Updated: nss - 3.12.2.0-2.el5.x86_64
  Aug 20 12:45:56 Updated: perl.i386 4:5.8.8-10.el5_2.3
  Aug 20 12:46:57 Installed: device-mapper-event.i386 1.02.24-1.el5
  Aug 20 12:51:21 Erased: libhugetlbfs-lib




