Log Samples boxbackup
---------------------

Client side  error messages: 
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: console

  Jun 13 11:15:24 exserver bbackupd[6147]: bbackupd: terminating due to exception Common OSFileOpenError (Can't open a file -- attempted to load a non-existant config file or bad file referenced within?) (1/2)
  Jun 13 11:18:36 exserver bbackupd[6632]: Starting daemon (config: /etc/box/bbackupd.conf) (version 0.10)
  Jun 14 04:01:01 exserver bbackupd[6632]: Incoming connection from local (UNIX socket)
  Jun 14 04:01:01 exserver bbackupd[6632]: Connection from command socket
  Jun 14 04:01:01 exserver bbackupd[6632]: bbackupd: terminating due to exception Common OSFileOpenError (Can't open a file -- attempted to load a non-existant config file or bad file referenced within?) (1/2)
  Jun 14 21:41:34 exserver bbackupd[30195]: Starting daemon (config: /etc/box/bbackupd.conf) (version 0.10)
  Jun 14 21:42:04 exserver bbackupd[30195]: Incoming connection from local (UNIX socket)
  Jun 14 21:42:04 exserver bbackupd[30195]: Connection from command socket
  Jun 14 21:42:04 exserver bbackupd[30195]: bbackupd: terminating due to exception Common OSFileOpenError (Can't open a file -- attempted to load a non-existant config file or bad file referenced within?) (1/2)
  Jun 14 21:43:06 exserver bbackupd[30469]: Starting daemon (config: /etc/box/bbackupd.conf) (version 0.10)
  Jun 14 21:43:09 exserver bbackupd[30469]: Incoming connection from local (UNIX socket)

