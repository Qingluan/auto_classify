Log Samples for Wordpress
-------------------------

.. code-block:: console

  Aug 11 17:45:34 ourhome WPsyslog[13016]: [127.0.0.1 admin] Info: Module:wpsyslog WPsyslog configuration has been changed.
  Aug 11 17:46:27 ourhome WPsyslog[13019]: [127.0.0.1 admin] Info: Module:wpsyslog WPsyslog configuration has been changed.
  Aug 11 17:54:48 ourhome WPsyslog[13092]: [127.0.0.1 na] Notice: Comment posted. Comment Id: #7, name: lalahaaa. Post Id: #3, name: newpost. Comment status: not approved.
  Aug 11 18:12:25 ourhome WPsyslog[13016]: [127.0.0.1 admin] Warning: Plugin deactivated. Plugin name: wpsyslog2/wpsyslog.php
  Aug 11 18:14:57 ourhome WPsyslog[13019]: [127.0.0.1 admin] Warning: Plugin deactivated. Plugin name: wpsyslog2/wpsyslog.php
  Aug 11 18:24:55 ourhome WPsyslog[13295]: [127.0.0.1 admin] Info: WPsyslog was successfully initialised: Database table created, default options added, user roles added.
  Aug 11 18:25:41 ourhome WPsyslog[14382]: [127.0.0.1 na] Info: User logged in. User name: admin (admin).
  Aug 11 18:25:55 ourhome WPsyslog[14382]: [127.0.0.1 admin] Info: User logged out. User name: admin (admin).
  Aug 11 18:26:05 ourhome WPsyslog[14382]: [127.0.0.1 na] Info: User authentication failed. User name: lala.
  Aug 11 18:26:17 ourhome WPsyslog[14382]: [127.0.0.1 na] Info: User authentication failed. User name: bla bla bla .
  Aug 11 18:48:47 ourhome WPsyslog[13019]: [127.0.0.1 admin] Info: WPsyslog configuration has been changed.
  Aug 11 18:49:48 ourhome WPsyslog[13015]: [127.0.0.1 admin] Warning: Plugin deactivated. Plugin name: wpsyslog2/wpsyslog.php
  Aug 11 18:52:59 ourhome WPsyslog[13295]: [127.0.0.1 admin] Warning: Plugin deactivated. Plugin name: wpsyslog2/wpsyslog.php
  Aug 11 18:52:59 ourhome WPsyslog[13295]: [127.0.0.1 admin] Warning: WPsyslog plugin has been deactivated.
  Aug 11 18:53:03 ourhome WPsyslog[13295]: [127.0.0.1 admin] Warning: WPsyslog plugin has been activated.



