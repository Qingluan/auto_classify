Log Samples from Aruba Wireless
-------------------------------

.. code-block:: console

  Jul  2 15:08:39 aruba-controller.company.com [192.168.1.25] sapd[156]: <106008> <ERRS> |AP aruba-ap.company.com@192.168.1.15 sapd|  AM 00:0b:86:e1:df:00: STA with MAC 00:17:f2:47:5f:0f is associating to a Rogue AP with SSID My Linksys and BSSID 00:18:39:cc:63:9f

