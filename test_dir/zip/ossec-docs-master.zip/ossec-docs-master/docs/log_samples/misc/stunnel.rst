Stunnel Logs
------------


Here is a log sample from `Stunnel for Windows <http://www.stunnel.org/>`_

Filename = C:\Program Files\Stunnel\stunnel.log
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: console

  2006.11.18 23:28:27 LOG5[900:924]: stunnel 4.16 on x86-pc-mingw32-gnu with OpenSSL 0.9.7i 14 Oct 2005
  2006.11.18 23:28:27 LOG5[900:924]: Threading:WIN32 SSL:ENGINE Sockets:SELECT,IPv6
  2006.11.18 23:28:36 LOG5[900:208]: No limit detected for the number of clients
  2006.11.19 07:11:32 LOG5[856:864]: stunnel 4.16 on x86-pc-mingw32-gnu with OpenSSL 0.9.7i 14 Oct 2005
  2006.11.19 07:11:32 LOG5[856:864]: Threading:WIN32 SSL:ENGINE Sockets:SELECT,IPv6
  2006.11.19 07:11:41 LOG5[856:208]: No limit detected for the number of clients
  2006.11.19 12:03:45 LOG5[856:1916]: TightVNC connected from 10.54.27.8:3891
  2006.11.19 12:03:45 LOG5[856:1916]: Connection closed: 299 bytes sent to SSL, 400 bytes sent to socket
  2006.11.19 12:03:52 LOG5[856:1372]: TightVNC connected from 10.54.27.8:3893
  2006.11.19 12:03:52 LOG5[856:1372]: Connection closed: 168 bytes sent to SSL, 331 bytes sent to socket
  2006.11.19 12:03:53 LOG5[856:2000]: TightVNC connected from 10.54.27.8:3895
  2006.11.19 12:03:54 LOG5[856:2000]: Connection closed: 49607 bytes sent to SSL, 316 bytes sent to socket
  2006.11.19 12:03:55 LOG5[856:1412]: TightVNC connected from 10.54.27.8:3897
  2006.11.19 12:03:55 LOG5[856:1412]: Connection closed: 49607 bytes sent to SSL, 244 bytes sent to socket
  2006.11.19 12:03:55 LOG5[856:1140]: TightVNC connected from 10.54.27.8:3899
  2006.11.19 12:03:55 LOG5[856:1140]: Connection closed: 49607 bytes sent to SSL, 316 bytes sent to socket
  2006.11.19 12:04:05 LOG5[856:1400]: TightVNC2 connected from 10.54.27.8:3901
  2006.11.19 12:04:05 LOG5[856:1400]: Connection closed: 36 bytes sent to SSL, 28 bytes sent to socket
  2006.11.19 12:04:08 LOG5[856:1416]: TightVNC2 connected from 10.54.27.8:3903
  2006.11.19 12:15:41 LOG5[856:1416]: Connection closed: 3237463 bytes sent to SSL, 35933 bytes sent to socket
  2006.11.19 12:15:44 LOG5[856:1752]: TightVNC connected from 10.54.27.8:3921
  2006.11.19 12:15:44 LOG5[856:1752]: Connection closed: 299 bytes sent to SSL, 433 bytes sent to socket
  2006.11.19 12:15:52 LOG5[856:3856]: TightVNC2 connected from 10.54.27.8:3923
  2006.11.19 12:30:45 LOG5[856:3856]: Connection closed: 1414271 bytes sent to SSL, 10775 bytes sent to socket
  2006.11.19 20:15:35 LOG5[856:1952]: TightVNC connected from 10.54.27.8:2421
  2006.11.19 20:15:35 LOG5[856:1952]: Connection closed: 299 bytes sent to SSL, 400 bytes sent to socket
  2006.11.19 20:15:43 LOG5[856:3032]: TightVNC connected from 10.54.27.8:2423
  2006.11.19 20:15:43 LOG5[856:3032]: Connection closed: 168 bytes sent to SSL, 331 bytes sent to socket
  2006.11.19 20:15:44 LOG5[856:3172]: TightVNC connected from 10.54.27.8:2425
  2006.11.19 20:15:44 LOG5[856:3172]: Connection closed: 49607 bytes sent to SSL, 316 bytes sent to socket
  2006.11.19 20:15:45 LOG5[856:3672]: TightVNC connected from 10.54.27.8:2427
  2006.11.19 20:15:45 LOG5[856:3672]: Connection closed: 49607 bytes sent to SSL, 244 bytes sent to socket
  2006.11.19 20:15:45 LOG5[856:3696]: TightVNC connected from 10.54.27.8:2429
  2006.11.19 20:15:45 LOG5[856:3696]: Connection closed: 49607 bytes sent to SSL, 316 bytes sent to socket
  2006.11.19 20:15:51 LOG5[856:3800]: TightVNC2 connected from 10.54.27.8:2431


Log entries made while a portscan was taking place:
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: console

  2006.11.19 20:36:44 LOG5[856:1540]: TightVNC connected from 10.54.27.5:42557
  2006.11.19 20:36:44 LOG3[856:1540]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:36:44 LOG5[856:1540]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:36:49 LOG5[856:2344]: TightVNC connected from 10.54.27.5:42570
  2006.11.19 20:36:49 LOG3[856:2344]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:36:49 LOG5[856:2344]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:36:54 LOG5[856:3504]: TightVNC connected from 10.54.27.5:42571
  2006.11.19 20:36:54 LOG3[856:3504]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:36:54 LOG5[856:3504]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:36:59 LOG5[856:3208]: TightVNC connected from 10.54.27.5:42572
  2006.11.19 20:36:59 LOG3[856:3208]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:36:59 LOG5[856:3208]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:04 LOG5[856:2944]: TightVNC connected from 10.54.27.5:42573
  2006.11.19 20:37:04 LOG3[856:2944]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:04 LOG5[856:2944]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:09 LOG5[856:2428]: TightVNC connected from 10.54.27.5:42574
  2006.11.19 20:37:09 LOG3[856:2428]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:09 LOG5[856:2428]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:14 LOG5[856:2044]: TightVNC connected from 10.54.27.5:42575
  2006.11.19 20:37:14 LOG3[856:2044]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:14 LOG5[856:2044]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:19 LOG5[856:1648]: TightVNC connected from 10.54.27.5:42576
  2006.11.19 20:37:19 LOG3[856:1648]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:19 LOG5[856:1648]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:24 LOG5[856:2436]: TightVNC connected from 10.54.27.5:42577
  2006.11.19 20:37:24 LOG3[856:2436]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:24 LOG5[856:2436]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:29 LOG5[856:3284]: TightVNC connected from 10.54.27.5:42578
  2006.11.19 20:37:29 LOG3[856:3284]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:29 LOG5[856:3284]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:34 LOG5[856:3356]: TightVNC connected from 10.54.27.5:42579
  2006.11.19 20:37:34 LOG3[856:3356]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:34 LOG5[856:3356]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:39 LOG5[856:3404]: TightVNC connected from 10.54.27.5:42580
  2006.11.19 20:37:39 LOG3[856:3404]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:39 LOG5[856:3404]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:44 LOG5[856:2928]: TightVNC connected from 10.54.27.5:42581
  2006.11.19 20:37:44 LOG3[856:2928]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:44 LOG5[856:2928]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:49 LOG5[856:1380]: TightVNC connected from 10.54.27.5:42582
  2006.11.19 20:37:49 LOG3[856:1380]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:49 LOG5[856:1380]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:54 LOG5[856:2068]: TightVNC connected from 10.54.27.5:42583
  2006.11.19 20:37:54 LOG3[856:2068]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:54 LOG5[856:2068]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:37:59 LOG5[856:3896]: TightVNC connected from 10.54.27.5:42584
  2006.11.19 20:37:59 LOG3[856:3896]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:37:59 LOG5[856:3896]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:04 LOG5[856:3252]: TightVNC connected from 10.54.27.5:42585
  2006.11.19 20:38:04 LOG3[856:3252]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:04 LOG5[856:3252]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:09 LOG5[856:3168]: TightVNC connected from 10.54.27.5:42586
  2006.11.19 20:38:09 LOG3[856:3168]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:09 LOG5[856:3168]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:11 LOG5[856:3280]: imaps connected from 10.54.27.5:42557
  2006.11.19 20:38:11 LOG3[856:3280]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:11 LOG5[856:3280]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:16 LOG5[856:3804]: TightVNC connected from 10.54.27.5:42587
  2006.11.19 20:38:16 LOG3[856:3804]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:16 LOG5[856:3804]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:19 LOG5[856:2816]: ssmtp connected from 10.54.27.5:42557
  2006.11.19 20:38:19 LOG3[856:2816]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:19 LOG5[856:2816]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:24 LOG5[856:1736]: TightVNC connected from 10.54.27.5:42588
  2006.11.19 20:38:24 LOG3[856:1736]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:24 LOG5[856:1736]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:27 LOG5[856:1544]: TightVNC2 connected from 10.54.27.5:42557
  2006.11.19 20:38:27 LOG3[856:1544]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:27 LOG5[856:1544]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:32 LOG5[856:3220]: TightVNC connected from 10.54.27.5:42589
  2006.11.19 20:38:32 LOG3[856:3220]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:32 LOG5[856:3220]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:37 LOG5[856:2804]: TightVNC connected from 10.54.27.5:42590
  2006.11.19 20:38:37 LOG3[856:2804]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:37 LOG5[856:2804]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:42 LOG5[856:3196]: TightVNC connected from 10.54.27.5:42591
  2006.11.19 20:38:42 LOG3[856:3196]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:42 LOG5[856:3196]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:47 LOG5[856:3772]: TightVNC connected from 10.54.27.5:42592
  2006.11.19 20:38:47 LOG3[856:3772]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:47 LOG5[856:3772]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:52 LOG5[856:3820]: TightVNC connected from 10.54.27.5:42593
  2006.11.19 20:38:52 LOG3[856:3820]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:52 LOG5[856:3820]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:38:57 LOG5[856:3152]: TightVNC connected from 10.54.27.5:42594
  2006.11.19 20:38:57 LOG3[856:3152]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:38:57 LOG5[856:3152]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:39:02 LOG5[856:2408]: TightVNC connected from 10.54.27.5:42595
  2006.11.19 20:39:02 LOG3[856:2408]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:39:02 LOG5[856:2408]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:39:07 LOG5[856:2056]: TightVNC connected from 10.54.27.5:42596
  2006.11.19 20:39:07 LOG3[856:2056]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:39:07 LOG5[856:2056]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 20:40:08 LOG5[856:2856]: pop3s connected from 10.54.27.5:42557
  2006.11.19 20:40:08 LOG3[856:2856]: SSL_accept: Peer suddenly disconnected
  2006.11.19 20:40:08 LOG5[856:2856]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket


More log samples:
^^^^^^^^^^^^^^^^^

.. code-block:: console

  2006.11.19 21:01:29 LOG5[856:3800]: Connection closed: 5567666 bytes sent to SSL, 122583 bytes sent to socket
  2006.11.19 22:55:50 LOG5[856:4052]: TightVNC2 connected from 10.54.27.8:4443
  2006.11.19 22:55:50 LOG3[856:4052]: SSL_read: Connection reset by peer (WSAECONNRESET) (10054)
  2006.11.19 22:55:50 LOG5[856:4052]: Connection reset: 12 bytes sent to SSL, 0 bytes sent to socket
  2006.11.19 22:56:31 LOG5[856:1824]: TightVNC connected from 10.54.27.8:4444
  2006.11.19 22:56:31 LOG3[856:1824]: SSL_read: Connection reset by peer (WSAECONNRESET) (10054)
  2006.11.19 22:56:31 LOG5[856:1824]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.20 00:25:31 LOG5[856:3104]: TightVNC connected from 10.54.27.8:4533
  2006.11.20 00:25:31 LOG3[856:3104]: SSL_read: Connection reset by peer (WSAECONNRESET) (10054)
  2006.11.20 00:25:31 LOG5[856:3104]: Connection reset: 0 bytes sent to SSL, 0 bytes sent to socket
  2006.11.20 00:25:41 LOG5[856:2848]: TightVNC2 connected from 10.54.27.8:4535
  2006.11.20 00:25:41 LOG3[856:2848]: SSL_read: Connection reset by peer (WSAECONNRESET) (10054)
  2006.11.20 00:25:41 LOG5[856:2848]: Connection reset: 12 bytes sent to SSL, 0 bytes sent to socket
  2006.11.20 00:48:57 LOG5[856:3964]: TightVNC connected from 10.54.27.8:1072
  2006.11.20 00:48:57 LOG5[856:3964]: Connection closed: 299 bytes sent to SSL, 400 bytes sent to socket
  2006.11.20 00:49:04 LOG5[856:3712]: TightVNC2 connected from 10.54.27.8:1074
  2006.11.20 00:55:34 LOG5[856:3712]: Connection closed: 3405756 bytes sent to SSL, 43743 bytes sent to socket


