Log samples from ClamAV
-----------------------

.. code-block:: console

  Jul  9 09:04:05 s69819 clamd[11292]: stream: HTML.Phishing.Pay-33 FOUND 
  Jul  9 11:40:02 s69819 clamd[11292]: stream: HTML.Phishing.Auction-111 FOUND 
  Jul  9 16:41:40 s69819 clamd[11292]: stream: HTML.Phishing.Pay-33 FOUND 
  Jul  9 16:45:26 s69819 clamd[11292]: stream: HTML.Phishing.Pay-33 FOUND 
  Jul  9 18:35:27 s69819 clamd[11292]: stream: HTML.Phishing.Pay-110 FOUND 
  Jul  9 21:00:06 s69819 clamd[11292]: stream: HTML.Phishing.Auction-111 FOUND 
  Jul 10 01:48:16 s69819 clamd[11292]: stream: HTML.Phishing.Pay-33 FOUND 
  Jul 10 03:35:54 s69819 clamd[11292]: stream: HTML.Phishing.Pay-110 FOUND 
  Jul 10 04:40:36 s69819 clamd[11292]: stream: HTML.Phishing.Auction-111 FOUND 
  Jul 10 06:29:49 s69819 clamd[11292]: stream: HTML.Phishing.Acc-4 FOUND 
  Jul 10 06:30:06 s69819 clamd[11292]: stream: HTML.Phishing.Acc-4 FOUND 
  Jul 10 16:57:19 s69819 clamd[11292]: stream: HTML.Phishing.Pay-110 FOUND 
  Jul 11 00:04:58 s69819 clamd[11292]: stream: HTML.Phishing.Pay-110 FOUND 
  Jul 11 09:00:06 s69819 clamd[11292]: stream: HTML.Phishing.Pay-110 FOUND 
  Jul 11 13:03:46 s69819 clamd[11292]: stream: HTML.Phishing.Auction-111 FOUND 
  Jul 11 19:51:21 s69819 clamd[11292]: stream: HTML.Phishing.Pay-110 FOUND 
  Jul 12 06:04:38 s69819 clamd[11292]: stream: HTML.Phishing.Pay-130 FOUND 
  Jul 12 13:41:55 s69819 clamd[11292]: stream: Worm.SomeFool.P FOUND 
  Jul 12 21:20:03 s69819 clamd[11292]: stream: HTML.Phishing.Pay-147 FOUND 
  Jul  2 06:34:56 s69819 clamd[20016]: stream: HTML.Phishing.Acc-4 FOUND 
  Jul  2 14:31:45 s69819 clamd[20016]: stream: HTML.Phishing.Acc-4 FOUND 
  Jul  2 17:50:54 s69819 clamd[11292]: stream: HTML.Phishing.Bank-497 FOUND 
  Jul  3 19:00:44 s69819 clamd[11292]: stream: HTML.Phishing.Auction-93 FOUND 
  Jul  4 02:57:06 s69819 clamd[11292]: stream: HTML.Phishing.Pay-51 FOUND 
  Jul  4 09:32:26 s69819 clamd[11292]: stream: HTML.Phishing.Acc-4 FOUND 
  Jul  4 11:20:08 s69819 clamd[11292]: stream: HTML.Phishing.Bank-475 FOUND 
  Jul  4 17:27:51 s69819 clamd[11292]: stream: HTML.Phishing.Pay-6 FOUND 
  Jul  4 19:01:05 s69819 clamd[11292]: stream: HTML.Phishing.Bank-490 FOUND 
  Jul  5 12:35:44 s69819 clamd[11292]: stream: Worm.SomeFool.P FOUND 
  Jul  5 16:42:24 s69819 clamd[11292]: stream: Exploit.HTML.IFrame FOUND 
  Jul  5 17:23:46 s69819 clamd[11292]: stream: Worm.SomeFool.Gen-2 FOUND 
  Jul  5 18:10:58 s69819 clamd[11292]: stream: HTML.Phishing.Pay-51 FOUND 
  Jul  5 20:27:00 s69819 clamd[11292]: stream: HTML.Phishing.Bank-546 FOUND 
  Jul  6 02:28:58 s69819 clamd[11292]: stream: HTML.Phishing.Bank-551 FOUND 
  Jul  6 15:16:18 s69819 clamd[11292]: stream: HTML.Phishing.Pay-37 FOUND 
  Jul  6 19:08:46 s69819 clamd[11292]: stream: HTML.Phishing.Pay-37 FOUND 
  Jul  7 05:20:35 s69819 clamd[11292]: stream: HTML.Phishing.Pay-130 FOUND 
  Jul  7 07:49:16 s69819 clamd[11292]: stream: HTML.Phishing.Pay-37 FOUND 
  Jul  7 17:25:14 s69819 clamd[11292]: stream: HTML.Phishing.Pay-33 FOUND 
  Jul  7 18:21:56 s69819 clamd[11292]: stream: HTML.Phishing.Pay-106 FOUND 
  Jul  8 04:30:32 s69819 clamd[11292]: stream: HTML.Phishing.Auction-102 FOUND 
  Jul  8 08:51:46 s69819 clamd[11292]: stream: HTML.Phishing.Pay-33 FOUND 
  Jul  8 10:15:01 s69819 clamd[11292]: stream: HTML.Phishing.Pay-152 FOUND 
  Jul  8 16:24:46 s69819 clamd[11292]: stream: HTML.Phishing.Pay-33 FOUND 


