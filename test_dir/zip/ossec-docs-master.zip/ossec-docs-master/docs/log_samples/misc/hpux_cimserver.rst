Log samples for HP-UX cimserver
-------------------------------

.. code-block:: console

  Dec 18 18:06:28 hostname cimserver[18575]: PGS17200: Authentication failed for user jones_b.
  Dec 18 18:06:29 hostname cimserver[18575]: PGS17200: Authentication failed for user domain\jones_b.


