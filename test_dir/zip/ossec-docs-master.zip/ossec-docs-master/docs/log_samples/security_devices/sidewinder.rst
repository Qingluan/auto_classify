Log samples for the Sidewinder firewall
---------------------------------------

.. code-block:: console

  Oct 24 03:03:55 hostname.com.au auditd: date="Oct 23 17:03:55 2008 GMT",fac=f_mail,area=a_server,type=t_attack,pri=p_major,pid=11945,ruid=0,euid=0,pgid=1787,logid=0,cmd=sendmail,domain=mta1,edomain=mta1,hostname=hostname.com.au,event=access deny,srcip=1.1.1.1,srcburb=outside,attackip=2.2.2.2,attackburb=outside,queueid=m9NH3tOH011945,reason="Sendmail determined that this session is not allowed.",information="550 5.7.1 TrustedSource determined this IP address is untrusted.  Reputation value: 0.0.0.140

