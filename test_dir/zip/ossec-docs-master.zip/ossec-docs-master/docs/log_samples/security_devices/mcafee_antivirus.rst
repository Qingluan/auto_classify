McAfee Logs
-----------


  11/9/2004	10:11:17 AM	Blocked by port blocking rule 	nmap.exe	Prevent mass mailing worms from sending mail	170.27.184.173
  11/9/2004	10:20:17 AM	Blocked by port blocking rule 	nmap.exe	Prevent mass mailing worms from sending mail	170.27.148.12
  11/9/2004	10:21:17 AM	Blocked by port blocking rule 	nmap.exe	Prevent mass mailing worms from sending mail	170.27.148.12
  11/11/2004	4:23:02 PM	Blocked by port blocking rule 	nmap.exe	Prevent mass mailing worms from sending mail	170.27.48.89
  11/16/2004	9:11:43 AM	Blocked by port blocking rule 	sshd.exe	Prevent IRC communication	127.0.0.1
  11/19/2004	9:38:51 AM	Blocked by port blocking rule 	sshd.exe	Prevent IRC communication	127.0.0.1
  11/20/2004	3:53:38 PM	Blocked by port blocking rule 	named.exe	Prevent IRC communication	127.0.0.1
  11/22/2004	5:59:37 PM	Blocked by port blocking rule 	Maxthon.exe	Prevent IRC communication	204.157.0.203
  11/22/2004	6:18:37 PM	Blocked by port blocking rule 	Maxthon.exe	Prevent IRC communication	66.154.9.99
  11/22/2004	6:20:37 PM	Blocked by port blocking rule 	Maxthon.exe	Prevent IRC communication	64.38.239.10
  12/3/2004	10:08:37 AM	Would be blocked by behaviour blocking rule  (rule is currently in warn mode) 	ComputerName\UserName	iexplore.exe	C:\Documents and Settings\UserName\Local Settings\Temporary Internet Files\Content.IE5\OXU74LIR\yinst_current[1].exe	Prevent Internet Explorer from launching anything from the Temp folder	Action blocked :Execute

