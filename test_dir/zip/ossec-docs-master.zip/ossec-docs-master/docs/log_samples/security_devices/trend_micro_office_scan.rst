Log Samples for Trend Micro Office Scan OSCE
--------------------------------------------

.. code-block:: console

  20090716<;>948<;>TROJ_Generic.DIT<;>25<;>3<;>0<;>C:\Documents and Settings\Administrator\Desktop\HyperSnap 6.02.01_EN\HprSnap6Man.chm<;>
  20090716<;>950<;>WORM_DOWNAD.A<;>1<;>3<;>0<;>C:\Documents and Settings\DCS_VM-ICRC-WFBS6\Local Settings\Temporary Internet Files\Content.IE5\9JK3DN67\sitb[1].jpg<;>
  20090716<;>951<;>WORM_DOWNAD.A<;>1<;>3<;>0<;>C:\Documents and Settings\Default User\Local Settings\Temporary Internet Files\Content.IE5\9JK3DN67\sitb[1].jpg<;>
  20090716<;>951<;>WORM_DOWNAD<;>0<;>4<;>0<;>Scanned by DCS<;>
  20090716<;>951<;>WORM_DOWNAD.A<;>0<;>4<;>0<;>Scanned by DCS<;>
  20090716<;>951<;>WORM_DOWNAD<;>0<;>4<;>0<;>Scanned by DCS<;>
  20090716<;>951<;>WORM_DOWNAD.A<;>0<;>4<;>0<;>Scanned by DCS<;>
  20090716<;>1122<;>WORM_DOWNAD.A<;>6<;>3<;>0<;>C:\WINDOWS\system32\jkbsctb.dll<;>
  20090716<;>1122<;>WORM_DOWNAD.A<;>0<;>4<;>0<;>Scanned by DCS<;>
  20090716<;>1122<;>WORM_DOWNAD<;>0<;>4<;>0<;>Scanned by DCS<;>
  20090716<;>1122<;>WORM_DOWNAD.A<;>0<;>4<;>0<;>Scanned by DCS<;>

