Log samples Mac
---------------

Authentication failure:
^^^^^^^^^^^^^^^^^^^^^^^

.. code-block:: console

  Aug 11 17:22:14 hocha com.apple.SecurityServer: authinternal failed to authenticate user root.
  Aug 11 17:22:14 hocha com.apple.SecurityServer: Failed to authorize right system.login.tty by process /usr/sbin/sshd for authorization created by /usr/sbin/sshd.
  Aug 11 17:22:16 hocha com.apple.SecurityServer: authinternal failed to authenticate user root.
  Aug 11 17:22:16 hocha com.apple.SecurityServer: Failed to authorize right system.login.tty by process /usr/sbin/sshd for authorization created by /usr/sbin/sshd.
  Aug 11 17:22:17 hocha com.apple.SecurityServer: authinternal failed to authenticate user root.
  Aug 11 17:22:17 hocha com.apple.SecurityServer: Failed to authorize right system.login.tty by process /usr/sbin/sshd for authorization created by /usr/sbin/sshd.


