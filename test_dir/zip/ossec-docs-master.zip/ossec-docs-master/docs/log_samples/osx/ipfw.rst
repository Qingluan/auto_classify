OS X IPFW Log Samples
---------------------

.. code-block:: console

  Aug 21 21:37:18 Macinfish ipfw:  12190 Deny TCP 83.227.141.74:4835 192.168.11.111:6881 in via en1
  Aug 21 21:37:27 Macinfish ipfw:  12190 Deny TCP 83.227.141.74:4835 192.168.11.111:6881 in via en1
  Aug 25 10:32:19 Macinfish ipfw:  12190 Deny TCP 192.168.11.123:64748 10.10.10.13:4444 in via en0
  Aug 27 14:32:58 Macinfish ipfw:  12190 Deny TCP 192.168.13.1:2060 192.168.13.104:5000 in via en1
  Aug 27 14:33:01 Macinfish ipfw:  12190 Deny TCP 192.168.13.1:2060 192.168.13.104:5000 in via en1
  Aug 27 14:33:07 Macinfish ipfw:  12190 Deny TCP 192.168.13.1:2060 192.168.13.104:5000 in via en1
  Aug 27 14:33:19 Macinfish ipfw:  12190 Deny TCP 192.168.13.1:2060 192.168.13.104:5000 in via en1
  Aug 27 14:33:43 Macinfish ipfw:  12190 Deny TCP 192.168.13.1:2060 192.168.13.104:5000 in via en1
  Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:23 in via en0
  Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:80 in via en0
  Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:443 in via en0
  Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:137 in via en0
  Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:138 in via en0
  Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:139 in via en0
  Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:445 in via en0
  Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:20 in via en0
  Aug 29 10:36:44 Macinfish ipfw:  12190 Deny TCP 192.168.10.2:10000 192.168.11.122:25 in via en0

