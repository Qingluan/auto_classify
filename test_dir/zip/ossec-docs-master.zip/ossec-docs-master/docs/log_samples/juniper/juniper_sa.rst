Log Samples for the Juniper SA
------------------------------

Login sucessful:
^^^^^^^^^^^^^^^^

.. code-block:: console

  07Dev2005 02:13:19 1.2.3.4 Juniper: 2005-12-07 02:13:19 - mike - [192.168.25.35] grp1(Users)[Users] - Login succeeded for mike/Users from 192.168.25.35.


Login failed:
^^^^^^^^^^^^^

.. code-block:: console

  07Dev2005 02:13:19 1.2.3.4 Juniper: 2005-12-07 02:13:19 - mike - [192.168.25.35] grp1(Users)[Users] - Login failed using auth server System Local (IVE Authentication).  Reason: Failed

