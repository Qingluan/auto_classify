W3C Extended Log File Format
----------------------------

.. code-block:: console

  #Software: Microsoft Internet Information Services 6.0
  #Version: 1.0
  #Date: 2006-08-13 00:00:35
  #Fields: date time s-ip cs-method cs-uri-stem cs-uri-query s-port cs-username c-ip cs(User-Agent) sc-status sc-substatus sc-win32-status 
  2006-08-13 00:00:35 10.3.4.2 GET /iisstart.htm - 80 - 10.3.0.5 check_http/1.7+(nagios-plugins+) 200 0 0
  2006-08-13 00:00:56 10.3.4.2 GET /iisstart.htm - 80 - 10.3.3.11 - 200 0 0
  2006-08-13 00:01:44 10.3.4.2 GET /iisstart.htm - 80 - 10.3.0.5 check_http/1.7+(nagios-plugins+) 200 0 0

