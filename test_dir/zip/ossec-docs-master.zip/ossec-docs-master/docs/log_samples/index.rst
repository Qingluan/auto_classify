.. OSSEC Rules documentation master file, created byA
   sphinx-quickstart on Sat Jul 17 09:20:30 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

===========
Log Samples
===========

Stuff
============


.. toctree::
   :maxdepth: 2
   :glob:

   apache/index
   auth/*
   linux/index
   windows/index
   bsd/*
   osx/*
   ftp/index
   nessus/*
   misc/index
   cisco/index
   checkpoint/*
   databases/*
   web/*
   dns/*
   firewalls/*
   email/*
   vmware/*
   
   ossec/*
  



