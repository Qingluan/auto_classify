Log Samples from PHP
--------------------

php-cgi log:
^^^^^^^^^^^^

.. code-block:: console

  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  Module 'gd' already loaded in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  PHP Startup: Unable to load dynamic library '/usr/lib/php5/20060613/gettext.so' - /usr/lib/php5/20060613/gettext.so: cannot open shared object file: No such file or directory in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  PHP Startup: Unable to load dynamic library '/usr/lib/php5/20060613/session.so' - /usr/lib/php5/20060613/session.so: cannot open shared object file: No such file or directory in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  PHP Startup: Unable to load dynamic library '/usr/lib/php5/20060613/zlib.so' - /usr/lib/php5/20060613/zlib.so: cannot open shared object file: No such file or directory in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  Module 'ADOdb' already loaded in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  Module 'gd' already loaded in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  Module 'ADOdb' already loaded in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  Module 'gd' already loaded in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  Module 'gd' already loaded in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  PHP Startup: Unable to load dynamic library '/usr/lib/php5/20060613/gettext.so' - /usr/lib/php5/20060613/gettext.so: cannot open shared object file: No such file or directory in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  Module 'mysql' already loaded in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  Module 'mysqli' already loaded in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  PHP Startup: Unable to load dynamic library '/usr/lib/php5/20060613/session.so' - /usr/lib/php5/20060613/session.so: cannot open shared object file: No such file or directory in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  PHP Startup: Unable to load dynamic library '/usr/lib/php5/20060613/zlib.so' - /usr/lib/php5/20060613/zlib.so: cannot open shared object file: No such file or directory in Unknown on line 0
  Jan 28 21:56:25 Lab12 php-cgi: PHP Warning:  Cannot load module 'pdo_sqlite' because required module 'pdo' is not loaded in Unknown on line 0

