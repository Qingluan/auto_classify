########################
User submitted Cookbooks
########################

.. warning::

   These recipes are user submitted, please reciew them thoroughly before implementing them in your own environment.
   No one cares about your environment more than you.


.. toctree::
    :maxdepth: 3
    :glob:

    recipes/*

