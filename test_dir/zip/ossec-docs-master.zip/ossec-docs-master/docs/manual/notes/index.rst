###########
Misc. Notes
###########

.. toctree::
    :maxdepth: 2

    active_directory_failures
    agentless_script
    checkpoint_configure
    compiled_rules
    correlate_snort
    custom_ar
    decoder_rule_relation
    disconnected_agent_alert
    extra_rules
    iptables_configuration
    log_checksums
    manager_backup
    multiple_files
    nmap_correlation
    ossec_syslog
    pix_configuration
    portscan_detection
    rule_groups
    white_list

