.. _manual_out_reports: 

Daily E-Mail Reports
--------------------

Daily E-Mail reports are summaries of the OSSEC alerts for the day.  


Configuration options
^^^^^^^^^^^^^^^^^^^^^

All of these configuration options should be specified in the /var/ossec/etc/ossec.conf. 

.. include:: ../../syntax/ossec_config.reports.trst 

.. include: ../../examples/output/report_output_examples.trst
