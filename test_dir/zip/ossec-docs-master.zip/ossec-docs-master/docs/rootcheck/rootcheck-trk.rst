
Information about the T.R.K rootkit 
===================================

This rootkit as a mix of some others. 

More Information
----------------

No more information is available.

Orgin of Rule
-------------

This rootkit was taken from chkrootkit: 

.. code-block:: sh

    ### T.R.K
    expertmode_output "${find} ${ROOTDIR}usr/bin -name soucemask -o -name ct" 

File
-----

- ``usr/bin/soucemask``
- ``usr/bin/sourcemask``

.. note::
    
    All files with an "*" need to be search in all system

If you have any more Information about this rootkits sent to rootkits at ossec.net 


