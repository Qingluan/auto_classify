
Information about the Beastkit Rootkit 
======================================

This rootkit was found on a RedHat 7.2 System in 01/2002. The rootkit setup
script includes the line "#Beastkit 7.0 - X-Org edition". Due to this fact,
we call it as "Beastkit 7.0". 

More Information
----------------

For more info, look at this analyse (author unknown): :ref:`analysis-beastkit`


Files
-----

- ``usr/include/rpc/ ../kit``
- ``usr/include/rpc/ ../kit2``
- ``usr/doc/.sl``
- ``usr/doc/.sp``
- ``usr/doc/.statnet``
- ``usr/doc/.logdsys``
- ``usr/doc/.dpct``
- ``usr/doc/.gifnocfi``
- ``usr/doc/.dnif``
- ``usr/doc/.nigol``
- ``*biba``
- ``*sniff/lins``

.. note::
    
    All files with an "*" need to be search in all system

If you have any more Information about this rootkits sent to rootkits at ossec.net 


