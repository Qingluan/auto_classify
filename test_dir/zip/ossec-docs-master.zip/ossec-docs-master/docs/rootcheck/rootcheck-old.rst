
Information about Old Rootkits 
==============================

These "Old Rootkits" are some old (obvious) rootkits, found in some systems 
years ago. They are not very well documented and because of that we 
call them only as "Old". 

Files
-----

- ``usr/include/rpc/ ../kit``
- ``usr/include/rpc/ ../kit2``
- ``usr/doc/.sl``
- ``usr/doc/.sp``
- ``usr/doc/.statnet``
- ``usr/doc/.logdsys``
- ``usr/doc/.dpct``
- ``usr/doc/.gifnocfi``
- ``usr/doc/.dnif``
- ``usr/doc/.nigol``
- ``*biba``
- ``*sniff/lins``

.. note::
    
    All files with an "*" need to be search in all system

If you have any more Information about this rootkits sent to rootkits at ossec.net 


