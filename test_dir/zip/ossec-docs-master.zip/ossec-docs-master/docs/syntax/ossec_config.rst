.. _syntax_ossec_config:

ossec.conf: syntax and options
=============================

.. toctree::
    :maxdepth: 2
    :glob:

    head_ossec_config*
    

