.. _rules_decoders:


Decoders Syntax
===============

Overview
--------


Options
-------

.. include:: ./decoders.trst
