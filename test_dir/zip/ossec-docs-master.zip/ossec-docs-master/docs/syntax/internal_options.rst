
.. _syntax_internal_config:

internal_options.conf: syntax and options
=========================================

.. toctree::
    :maxdepth: 2
    :glob:

    head_internal_options*
