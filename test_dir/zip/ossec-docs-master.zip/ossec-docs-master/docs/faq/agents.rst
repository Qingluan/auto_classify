.. _faq_agents:

Agents: FAQ
-------------

.. contents:: 
    :local:


Why can't agent IDs be re-used?
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

When looking at historical alerts you don't want to associate alerts from one system to be attributed to another, especially if the those alerts are from an unrelated and retired system.








