
.. _clear_stats:

clear_stats
===========

Clear the events stats 

clear_stats argument options 
----------------------------

.. program:: clear_stats 

.. option:: -h 

    Print and display a help message of all available options to clear_stats 

.. option:: -a 

    Clear all the stats (averages). 

.. option:: -d 

    Clear the daily averages. 

.. option:: -w 

    Clear the weekly averages. 


