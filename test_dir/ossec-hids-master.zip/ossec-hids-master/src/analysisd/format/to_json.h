
#ifndef __TO_JSON_H__
#define __TO_JSON_H__

char *Eventinfo_to_jsonstr(Eventinfo *lf);

#endif 
